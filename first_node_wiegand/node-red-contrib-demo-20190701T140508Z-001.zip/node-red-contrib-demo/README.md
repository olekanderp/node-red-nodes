# node-red-contrib-wago
[Node-RED](http://nodered.org/) nodes to easily map WAGO 750-49X Power Measurement Modules. 

A Bunch Of Text

##Example
![Example](http://i.imgur.com/m2s6JRl.png)

##Version history
* 0.0.1	First release
  * Untested
